import tkinter as tk
from tkinter import messagebox
import xml.etree.ElementTree as ET
import uuid
import random
from datetime import datetime, timedelta, date, timezone
import os
import secrets
from zoneinfo import ZoneInfo
import string

successTxnRefIds = dict()

def generate_random_transaction(s):
    txnDate = date.today().strftime('%Y-%m-%d')
    clearingTimestamp = (datetime.now(timezone(timedelta(hours=5, minutes=30)))).strftime('%Y-%m-%dT%H:%M:%S+05:30')
    characters = string.ascii_uppercase + string.digits
    msgId = ''.join(random.choices(characters, k=34))
    txnReferenceId = ''.join(random.choices(characters, k=20))
    settlementCycleId = "00"+str(s)+txnDate.replace("-","")+"00"
    responseCode = random.choice(['000', '001', '200'])
    success = ["PAYMENT", "FORCE PAYMENT", "FORCE PAYMENT PRE-ARBITRATION", "FORCE PAYMENT PARTIAL GOOD FAITH", "FORCE PAYMENT FULL GOOD FAITH", "FORCE PAYMENT ARBITRATION"]
    refund = ["CREDIT ADJUSTMENT", "REFUND", "REFUND PRE-ARBITRATION", "REFUND PARTIAL GOOD FAITH", "REFUND FULL GOOD FAITH", "REFUND ARBITRATION"]
    all_types = success + refund
    weights = [0.7/len(success)]*len(success) + [0.3/len(refund)]*len(refund)
    mti = random.choices(all_types, weights=weights, k=1)[0]
    txnAmount = '0'
    if mti in success and responseCode == '000':
        txnAmount = str(random.randint(1000, 1000000))
        successTxnRefIds[txnReferenceId]=txnAmount
    elif mti in refund and successTxnRefIds == {} :
        mti = random.choice(success)
        responseCode = "001"
    elif mti in refund:
        txnReferenceId = random.choice(list(successTxnRefIds.keys()))
        txnAmount = "-"+successTxnRefIds[txnReferenceId]
        del successTxnRefIds[txnReferenceId]
    else :
        txnAmount = str(0)

    transaction = {
        'msgId': msgId,
        'refId': msgId,
        'origRefId': 'NA',
        'mti': mti,
        'txnReferenceId': txnReferenceId,
        'txnType': 'PAYMENT',
        'txnDate': txnDate,
        'customerOUId': random.choice(['PP11', 'PP22', 'PP33']),
        'billerOUId': random.choice(['HD51', 'JK22', 'JK33']),
        'responseCode': responseCode,
        'txnCurrencyCode': '356',
        'txnAmount': txnAmount,
        'customerConvenienceFee': '0.0000',
        'billerFee': f"{random.uniform(-500, 0):.4f}",
        'billerOUSwitchingFee': f"{random.uniform(-50, 0):.4f}",
        'penaltyFee': '0.0000',
        'clearingTimestamp': clearingTimestamp,
        'paymentChannel': random.choice(['MOB', 'WEB', 'CARD']),
        'paymentMode': random.choice(['Internet Banking', 'Credit Card', 'UPI']),
        'billerOUCountMonth': '12',
        'billerId': 'HDFC00000NATTK',
        'billerCategory': 'Loan Repayment',
        'splitPay': 'false',
        'reversal': 'false',
        'decline': 'false',
        'casProcessed': 'true',
        'settlementCycleId': settlementCycleId,
        'customerConvenienceFeeCGST': '0.0000',
        'customerConvenienceFeeIGST': '0.0000',
        'customerConvenienceFeeSUTGST': '0.0000',
        'billerFeeCGST': '0.0000',
        'billerFeeIGST': f"{random.uniform(-90, 0):.4f}",
        'billerFeeSUTGST': '0.0000',
        'billerOUSwitchingFeeCGST': f"{random.uniform(-5, 0):.4f}",
        'billerOUSwitchingFeeIGST': '0.0000',
        'billerOUSwitchingFeeSUTGST': f"{random.uniform(-5, 0):.4f}",
        'penaltyFeeCGST': '0.0000',
        'penaltyFeeIGST': '0.0000',
        'penaltyFeeSUTGST': '0.0000',
        'offUsPay': 'true',
        'remarks': 'NA'
    }
    return transaction

def indent(elem, level=0):
    pad = "\n" + level * "  "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = pad + "  "
        for child in elem:
            indent(child, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = pad
    else:
        if not elem.tail or not elem.tail.strip():
            elem.tail = pad

def create_xml(transactions_list, output_file):
    rawfile = ET.Element('RAWFile', ouId="HD51")
    for transaction in transactions_list:
        transactions = ET.SubElement(rawfile, 'transactions')
        for key, value in transaction.items():
            ET.SubElement(transactions, key).text = value

    signature = ET.SubElement(rawfile, 'Signature', xmlns="http://www.w3.org/2000/09/xmldsig#")
    signed_info = ET.SubElement(signature, 'SignedInfo')
    ET.SubElement(signed_info, 'CanonicalizationMethod', Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315")
    ET.SubElement(signed_info, 'SignatureMethod', Algorithm="http://www.w3.org/2001/04/xmldsig-more#rsa-sha256")
    reference = ET.SubElement(signed_info, 'Reference', URI="")
    transforms = ET.SubElement(reference, 'Transforms')
    ET.SubElement(transforms, 'Transform', Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature")
    ET.SubElement(reference, 'DigestMethod', Algorithm="http://www.w3.org/2001/04/xmlenc#sha256")
    ET.SubElement(reference, 'DigestValue').text = "x1eQX0UhXo3I2297x2LUIrC5ufElD4eWviOa4W+ahdA="
    ET.SubElement(signature, 'SignatureValue').text = "SEP/Z813RbxhHg3MGGQAm/BxGw9gBrgXY12I2zk+Pns5MgMtzIwzzM6LAF+BJCj18GWhP5azyz2q"

    indent(rawfile)
    tree = ET.ElementTree(rawfile)
    tree.write(output_file, encoding="UTF-8", xml_declaration=True)

def generate_transactions_in_single_file(count, s, output_dir):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    transactions_list = []
    for _ in range(count):
        txn = generate_random_transaction(s)
        transactions_list.append(txn)
    i = 1
    while True:
        output_file = os.path.join(output_dir, f"transactions_{i}.xml")
        if not os.path.exists(output_file):
            break
        i += 1
    create_xml(transactions_list, output_file)

def run_generation():
    try:
        n = int(entry_count.get())
        s = int(entry_cycle.get())
        generate_transactions_in_single_file(n, s, "./output_xml")
        messagebox.showinfo("Success", f"Generated {n} transactions.")
    except Exception as e:
        messagebox.showerror("Error", str(e))

root = tk.Tk()
root.title("Test Data Generator")

tk.Label(root, text="No of transactions to be generated:").grid(row=0, column=0, padx=10, pady=5, sticky="e")
entry_count = tk.Entry(root)
entry_count.grid(row=0, column=1, padx=10, pady=5)

tk.Label(root, text="Enter the settlement cycle id:").grid(row=1, column=0, padx=10, pady=5, sticky="e")
entry_cycle = tk.Entry(root)
entry_cycle.grid(row=1, column=1, padx=10, pady=5)

tk.Button(root, text="Generate", command=run_generation).grid(row=2, column=0, columnspan=2, pady=10)

root.mainloop()